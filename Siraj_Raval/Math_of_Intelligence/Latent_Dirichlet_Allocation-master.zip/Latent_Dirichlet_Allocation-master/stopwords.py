STOP_WORDS = set([
"a","an","the","its",
"are","was","were","does",
"and","or","but",
"this","that","which"
"here","there","where",
"of","on","in","from","about","over","for",
"out","into","after","with"
])


PUNCTUATION = set([',', '.', ';', '?'])
